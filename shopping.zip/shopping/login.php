<?php

include 'db_connection.php';
session_start();
$conn = OpenCon();
$invalid = 0;
$login = 0;

if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $pass = $_POST['password'];

    $select ="SELECT * FROM users WHERE username='$username' AND password = '$pass'";
    $result = mysqli_query($conn,$select);
    
    if(mysqli_num_rows($result)>0){
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username']=$username;
        $_SESSION['user_id'] =$row['id'];
        header('Location:index.php');
        echo $username;

    }
    else {
        echo "Incorrect Credentials";
    }
    
}


CloseCon($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

</head>
<style>
    form {
        padding: 20px;
        background-color: #ede3ea;
        border-radius: 10px;
       
    }
    h1 {
        text-align: center; 
    }
    input {
        padding: 9px;
        width: 95%;
        border: none !important;
    }
    button{
        width: 100%;
        padding: 10px;
        border: none !important;
        color: #fff !important;
        font-size: 20px;
        background-color: #32cd7e;
        border-radius: 15px;
        cursor: pointer;
}
</style>
<body>
<?php 
        if($invalid){
            echo '<div class="alert alert-danger" role="alert">
            <strong>Ohh no sorry</strong> 
        
        </div>';
        }
    ?>
    <?php 
        if($login){
            echo '<div class="alert alert-success" role="alert">
            <strong>Success</strong> Successfully Log.
        
        </div>';
        }
    ?>
    <div style="width:500px; margin:0 auto;">
        <form action="" method="post" >
            <h1>Login</h1>
            <label for="username">Username</label>
            <br>
            <br>
            <input type="text" placeholder="username" value="" name="username"/>
            <br>
            <br>
            <label for="password">Password</label>
            <br>
            <br>
            <input type="password" placeholder="password" value="" name="password"/>
            <br>
            <br>
            <input type="submit" name="submit" value="Login" style="background-color:green;color:#fff;"/>
            <div style=" margin:10px 0 0 auto">Don't have an account?
                <a href="signUp.php">Create an account</a>
            </div>
            
        </form>
    </div>
</body>
</html>